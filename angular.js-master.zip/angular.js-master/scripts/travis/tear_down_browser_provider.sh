#!/bin/bash
# Has to be run from project root directory.

./lib/${BROWSER_PROVIDER}/teardown_tunnel.sh
